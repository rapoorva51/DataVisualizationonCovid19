#!/usr/bin/env python
# coding: utf-8

# In[1]:


import plotly.express as px 
import plotly.graph_objects as go
import plotly.figure_factory as ff
from plotly.subplots import make_subplots

import folium
import seaborn as sns

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

import math
import random
from datetime import timedelta

import warnings 
warnings.filterwarnings('ignore')

# color pallette
cnf = '#393e46'
dth = '#ff2e63'
rec = '#21bf73'
act = '#fe9801'
hec = '#b3d852'
hsl = '#ee8f8b'


# In[2]:


import plotly as py 
py.offline.init_notebook_mode(connected = True)


# In[3]:


import os
try:
    os.system("rm -rf Covid-19-Preprocessed-Dataset")
except:
    print('File does not exist')


# In[4]:


df = pd.read_csv('covid_19_data_cleaned.csv',parse_dates = ['Date'])
country_daywise = pd.read_csv('country_daywise.csv',parse_dates = ['Date'])
countrywise = pd.read_csv('countrywise.csv')
daywise = pd.read_csv('daywise.csv',parse_dates = ['Date'])


# In[5]:


df


# In[6]:


df['Province/State'] = df['Province/State'].fillna("")
df


# In[7]:


confirmed = df.groupby('Date').sum() ['Confirmed'].reset_index()


# In[8]:


recovered = df.groupby('Date').sum() ['Recovered'].reset_index()


# In[9]:


deaths =  df.groupby('Date').sum() ['Deaths'].reset_index()


# In[10]:


df.isnull().sum()


# In[11]:


df.info()


# In[12]:


df.query('Country == "US"')


# # Worldwide Total Cases,Recoverd and Deaths.

# In[13]:


fig = go.Figure()
fig.add_trace(go.Scatter(x = confirmed['Date'],y = confirmed['Confirmed'],mode = 'lines+markers', name = 'Confirmed cases',line = dict(color = "Orange",width = 4)))
fig.add_trace(go.Scatter(x = recovered['Date'],y = recovered['Recovered'],mode = 'lines+markers', name = 'Recovered cases',line = dict(color = "Green",width = 4)))
fig.add_trace(go.Scatter(x = deaths['Date'],y = deaths['Deaths'],mode = 'lines+markers', name = 'Deaths cases',line = dict(color = "Yellow",width = 4)))
fig.update_layout(title = "Worldwide Covid-19 Cases",xaxis_tickfont_size=14,yaxis = dict(title = "Number of Cases"))
fig.show()


# # Cases Density Animation on World Map

# In[14]:


df['Date'] = df['Date'].astype(str)


# In[15]:


df.info()


# In[16]:


fig = px.density_mapbox(df,lat = 'Lat',lon = 'Long',hover_name = 'Country',hover_data = ['Confirmed','Recovered','Deaths'],animation_frame = 'Date',color_continuous_scale = 'Portland',radius = 7,zoom =0,height = 700)
fig.update_layout(title = "Worldwide Covid-19 Cases with Time laps")
fig.update_layout(mapbox_style = 'open-street-map',mapbox_center_lon = 0)
fig.show()


# # Total Cases on Ships

# In[17]:


df['Date'] = pd.to_datetime(df['Date'])
df.info()


# In[18]:


ship_rows = df['Province/State'].str.contains('Grand Princess') | df['Country'].str.contains('Diamond Princess') | df['Country'].str.contains('MS Zaandam')
df[ship_rows]


# In[19]:


ship = df[ship_rows]


# In[20]:


df = df[~ship_rows]


# In[21]:


ship_latest = ship[ship['Date'] == max(ship['Date'])]
ship_latest


# In[22]:


ship_latest.style.background_gradient(cmap = 'Pastel1_r')


# # Cases over the Time with Area Plot

# In[23]:


temp = df.groupby('Date')['Confirmed','Recovered','Deaths','Active'].sum().reset_index()
temp


# In[24]:


temp = temp[temp['Date'] == max(temp['Date'])].reset_index(drop = True)
temp


# In[25]:


tm = temp.melt(id_vars = 'Date',value_vars = ['Active','Recovered','Deaths'])
fig = px.treemap(tm, path = ['variable'],values = 'value',height = 250,width = 800,color_discrete_sequence = [act,rec,dth])

fig.data[0].textinfo = 'label+text+value'
fig.show()


# In[26]:


temp = df.groupby('Date')['Recovered','Deaths','Active'].sum().reset_index()


# In[27]:


temp = temp.melt(id_vars = 'Date',value_vars = ['Active','Deaths','Recovered'],var_name = 'Case', value_name = 'Count')
fig = px.area(temp, x = 'Date',y = 'Count',color = 'Case', height = 600,title='Cases over time',color_discrete_sequence = [act,rec,dth])
fig.update_layout(xaxis_rangeslider_visible = True)
fig.show()


# # Folium Maps

# In[28]:


temp = df[df['Date'] == max(df['Date'])]

m = folium.Map(location = [0, 0],tiles = 'cartodbpositron',min_zoom = 1,max_zoom = 4,zoom_start = 8)

for i in range (0, len(temp)) :
    folium.Circle(location = [temp.iloc[i]['Lat'],temp.iloc[i]['Long']],color = '#7990f5',fill = '#b3d852',
                  tooltip = '<li><bold> Country : ' + str (temp.iloc[i]['Country']) +
                             '<li><bold> Province : ' + str (temp.iloc[i]['Province/State']) +
                              '<li><bold> Confirmed : ' + str (temp.iloc[i]['Confirmed']) +
                               '<li><bold> Deaths : ' + str (temp.iloc[i]['Deaths']), 
                  radius = int(temp.iloc[i]['Confirmed'])**0.5).add_to(m)
    
    
m


# # Confirmed cases with Choropleth Maps

# In[29]:


fig = px.choropleth(country_daywise,locations = 'Country',locationmode = 'country names',color = np.log(country_daywise['Confirmed']),
                    hover_name = 'Country',animation_frame = country_daywise['Date'].dt.strftime('%Y-%m-%d'),
                    title = 'Cases over Time',color_continuous_scale = px.colors.sequential.Inferno)
fig.update(layout_coloraxis_showscale = True)
fig.show()


# # Deaths and Recoveries per 100 Cases

# In[30]:


fig_c = px.bar(daywise,x = 'Date',y = 'Confirmed',color_discrete_sequence = [act])
fig_d = px.bar(daywise,x = 'Date',y = 'Deaths',color_discrete_sequence = [rec])

fig = make_subplots(rows = 1,cols = 2,shared_xaxes=False,horizontal_spacing = 0.1,
                   subplot_titles = ('Confirmed cases','Death Cases'))

fig.add_trace(fig_c['data'][0],row = 1,col = 1)
fig.add_trace(fig_d['data'][0],row = 1,col = 2)

fig.update_layout(height = 480)

fig.show()


# # Confirmed and Death Cases with Static Colormap

# In[31]:


fig_c = px.choropleth(countrywise,locations = 'Country',locationmode = 'country names',
                     color = np.log(countrywise['Confirmed']),hover_name = 'Country',
                     hover_data = ['Confirmed'])

temp = countrywise[countrywise['Deaths']>0]

fig_d = px.choropleth(temp,locations = 'Country',locationmode = 'country names',
                     color = np.log(temp['Deaths']),hover_name = 'Country',
                     hover_data = ['Deaths'])

fig = make_subplots(rows = 1,cols = 2,subplot_titles = ['Confirmed','Deaths'],
                    specs = [[{'type':'choropleth'},{'type' : 'choropleth'}]])  
    
fig.add_trace(fig_c['data'][0],row = 1 , col = 1)
fig.add_trace(fig_d['data'][0],row = 1, col = 2)

fig.show()


# In[32]:


daywise.columns


# In[33]:


fig1 = px.line(daywise,x = 'Date',y = 'Deaths / 100 Cases',color_discrete_sequence = [dth])
fig2 = px.line(daywise,x = 'Date',y = 'Recovered / 100 Cases',color_discrete_sequence = [cnf])
fig3 = px.line(daywise,x = 'Date',y = 'Deaths / 100 Recovered',color_discrete_sequence = [act])

fig = make_subplots(rows = 1,cols = 3,shared_xaxes = False,
                   subplot_titles = ('Deaths / 100 Cases','Recovered / 100 Cases','Deaths / 100 Recovered'))

fig.add_trace(fig1['data'][0],row = 1,col = 1)
fig.add_trace(fig2['data'][0],row = 1,col = 2)
fig.add_trace(fig3['data'][0],row = 1,col = 3)

fig.update_layout(height = 600)

fig.show()


# # New Cases and Number of Countries.

# In[34]:


fig_c = px.bar(daywise,x = 'Date',y = 'Confirmed',color_discrete_sequence = [dth])
fig_d = px.bar(daywise,x = 'Date',y = 'No. of Countries',color_discrete_sequence = [cnf])

fig = make_subplots(rows = 1,cols = 2,shared_xaxes = False,horizontal_spacing = 0.1,
                   subplot_titles = ('Number of New Cases Per Day','Number of Countries'))

fig.add_trace(fig_c['data'][0],row = 1,col = 1)
fig.add_trace(fig_d['data'][0],row = 1,col = 2)

fig.show()
                    


# # Top 15 Countries Case Analysis

# In[35]:


top = 15

fig_c = px.bar(countrywise.sort_values('Confirmed').tail(top),x = 'Confirmed',y = 'Country',
               text ='Confirmed',orientation = 'h' ,color_discrete_sequence = [rec])
fig_d = px.bar(countrywise.sort_values('Deaths').tail(top),x = 'Deaths',y = 'Country',
               text ='Deaths',orientation = 'h' ,color_discrete_sequence = [cnf])


fig = make_subplots(rows = 5, cols = 2,shared_xaxes = False,horizontal_spacing = 0.14,
                 vertical_spacing = .1,
                 subplot_titles = ('Confirmed Cases','Deaths Reported'))

fig.add_trace(fig_c['data'][0],row = 1,col = 1)
fig.add_trace(fig_c['data'][0],row = 1,col = 2)

fig.update_layout(height = 4000)

fig.show()


# In[36]:


countrywise.columns


# In[37]:


top = 15

fig_c = px.bar(countrywise.sort_values('Confirmed').tail(top),x = 'Confirmed',y = 'Country',
               text ='Confirmed',orientation = 'h' ,color_discrete_sequence = ['#697681'])

fig_d = px.bar(countrywise.sort_values('Deaths').tail(top),x = 'Deaths',y = 'Country',
               text ='Deaths',orientation = 'h' ,color_discrete_sequence = ['#d1933e'])


fig_a = px.bar(countrywise.sort_values('Active').tail(top),x = 'Active',y = 'Country',
               text ='Active',orientation = 'h' ,color_discrete_sequence = [hec])

fig_r = px.bar(countrywise.sort_values('Recovered').tail(top),x = 'Recovered',y = 'Country',
               text ='Recovered',orientation = 'h' ,color_discrete_sequence = ['#ee8f8b'])

fig_dc = px.bar(countrywise.sort_values('Deaths / 100 Cases').tail(top),x = 'Deaths / 100 Cases',y = 'Country',
               text ='Deaths / 100 Cases',orientation = 'h' ,color_discrete_sequence = ['#00ffd2'])

fig_rc = px.bar(countrywise.sort_values('Recovered / 100 Cases').tail(top),x = 'Recovered / 100 Cases',y = 'Country',
               text ='Recovered / 100 Cases',orientation = 'h' ,color_discrete_sequence = ['#fb5a45'])



fig = make_subplots(rows = 5, cols = 3,shared_xaxes = False,horizontal_spacing = 0.14,
                 vertical_spacing = .01,
                 subplot_titles = ('Confirmed Cases','Deaths Reported','Recovered cases','Active Cases','Deaths / 100 Cases','Recovered / 100 Cases'))

fig.add_trace(fig_c['data'][0],row = 1,col = 1)
fig.add_trace(fig_c['data'][0],row = 1,col = 2)
fig.add_trace(fig_a['data'][0],row = 1,col = 3)

fig.add_trace(fig_r['data'][0],row = 2,col = 1)
fig.add_trace(fig_dc['data'][0],row = 2,col = 2)
fig.add_trace(fig_rc['data'][0],row = 2,col = 3)

fig.update_layout(height = 5000)

fig.show()


# # Save Static Plots

# In[38]:


if not os.path.exists('images') :
    os.mkdir('images')


# In[39]:


fig.write_image('images/fig.png')


# # Scatter Plot for Death Vs Confirmed cases

# In[40]:


countrywise.sort_values('Deaths',ascending = False).iloc[:15,:]


# In[41]:


top = 15
fig = px.scatter(countrywise.sort_values('Deaths',ascending = False).head(top),
                x = 'Confirmed',y = 'Deaths',color = 'Country',size = 'Confirmed',height = 700,
                text = 'Country',log_x = True,log_y = True,title = 'Death Vs Confirmed Cases(Cases are on log10 Scale)')
fig.update_layout(showlegend = True)
fig.update_layout(xaxis_rangeslider_visible = True)
fig.show()


# # Confirmed,Deaths,New Cases Vs Country and Date

# # Bar Plot

# In[42]:


fig = px.bar(country_daywise,x = 'Date',y = 'Confirmed',color = 'Country',height = 600,
            title = 'Confirmed',color_discrete_sequence = px.colors.cyclical.mygbm)
fig.show()


# In[43]:


fig = px.bar(country_daywise,x = 'Date',y = 'Deaths',color = 'Country',height = 600,
            title = 'Deaths',color_discrete_sequence = px.colors.sequential.Plasma)
fig.show()


# In[44]:


fig = px.bar(country_daywise,x = 'Date',y = 'Recovered',color = 'Country',height = 600,
            title = 'Recovered',color_continuous_scale=px.colors.sequential.Inferno)
fig.show()


# In[45]:


fig = px.bar(country_daywise,x = 'Date',y = 'New Cases',color = 'Country',height = 900,
            title = 'New Cases',color_continuous_scale=px.colors.diverging.Tealrose)
fig.show()


# # Line Plots

# In[46]:


fig = px.line(country_daywise,x = 'Date',y = 'Confirmed',color = 'Country',height = 600,
            title = 'Confirmed',color_discrete_sequence = px.colors.sequential.Plasma)
fig.show()


# In[47]:


fig = px.line(country_daywise,x = 'Date',y = 'Deaths',color = 'Country',height = 600,
            title = 'Deaths',color_discrete_sequence = px.colors.cyclical.mygbm)
fig.show()


# In[48]:


fig = px.line(country_daywise,x = 'Date',y = 'Recovered',color = 'Country',height = 600,
            title = 'Recovered',color_discrete_sequence = px.colors.cyclical.mygbm)
fig.show()


# In[49]:


fig = px.line(country_daywise,x = 'Date',y = 'New Cases',color = 'Country',height = 600,
            title = 'New Cases',color_discrete_sequence = px.colors.sequential.Plasma)
fig.show()


# # Growth Rate After 100 Cases

# In[50]:


gt_100 = country_daywise[country_daywise['Confirmed']>100]['Country'].unique()
temp = df[df['Country'].isin(gt_100)]

temp = temp.groupby(['Country','Date'])['Confirmed'].sum().reset_index()
temp = temp[temp['Confirmed']>100]

min_date = temp.groupby('Country')['Date'].min().reset_index()
min_date.columns = ['Country','Min Date']

from_100th_case = pd.merge(temp,min_date,on = 'Country')
from_100th_case['N days'] = (from_100th_case['Date'] - from_100th_case['Min Date']).dt.days

fig = px.line(from_100th_case,x = 'N days',y = 'Confirmed',color = 'Country',title = 'N days from 100 cases',height = 800)

fig.show()


# # Growth Rate of 1000 Cases

# In[51]:


gt_1000 = country_daywise[country_daywise['Confirmed']>1000]['Country'].unique()
temp = df[df['Country'].isin(gt_1000)]

temp = temp.groupby(['Country','Date'])['Confirmed'].sum().reset_index()
temp = temp[temp['Confirmed']>1000]

min_date = temp.groupby('Country')['Date'].min().reset_index()
min_date.columns = ['Country','Min Date']

from_1000th_case = pd.merge(temp,min_date,on = 'Country')
from_1000th_case['N days'] = (from_1000th_case['Date'] - from_1000th_case['Min Date']).dt.days

fig = px.line(from_1000th_case,x = 'N days',y = 'Confirmed',color = 'Country',title = 'N days from 1000 cases',height = 800)

fig.show()


# # Groth Rate of 10,000 Cases

# In[52]:


gt_10000 = country_daywise[country_daywise['Confirmed']>10000]['Country'].unique()
temp = df[df['Country'].isin(gt_10000)]

temp = temp.groupby(['Country','Date'])['Confirmed'].sum().reset_index()
temp = temp[temp['Confirmed']>10000]

min_date = temp.groupby('Country')['Date'].min().reset_index()
min_date.columns = ['Country','Min Date']

from_10000th_case = pd.merge(temp,min_date,on = 'Country')
from_10000th_case['N days'] = (from_10000th_case['Date'] - from_10000th_case['Min Date']).dt.days

fig = px.line(from_10000th_case,x = 'N days',y = 'Confirmed',color = 'Country',title = 'N days from 10000 cases',height = 800)

fig.show()


# # Tree Map Analysis

# ##                                     Confirmed Cases

# In[53]:


full_latest = df[df['Date'] == max(df['Date'])]

fig = px.treemap(full_latest.sort_values(by = 'Confirmed',ascending = False).reset_index(drop = True),
                path = ['Country','Province/State'],values = 'Confirmed',height = 900,
                title = 'Number of Confirmed Cases',
                color_discrete_sequence = px.colors.qualitative.Dark2)

fig.data[0].textinfo = 'label+text+value'

fig.show()


# ## Death Cases

# In[54]:


full_latest = df[df['Date'] == max(df['Date'])]

fig = px.treemap(full_latest.sort_values(by = 'Deaths',ascending = False).reset_index(drop = True),
                path = ['Country','Province/State'],values = 'Deaths',height = 900,
                title = 'Number of Death Cases',
                color_continuous_scale=px.colors.sequential.Inferno )

fig.data[0].textinfo = 'label+text+value'

fig.show()


# # First and Last Case Report Time

# In[55]:


first_date = df[df['Confirmed'] >0]
first_date = first_date.groupby('Country')['Date'].agg(['min']).reset_index()

last_date = df.groupby(['Country','Date'])['Confirmed','Deaths','Recovered']
last_date = last_date.sum().diff().reset_index()

mask = (last_date['Country'] != last_date['Country'].shift(1))

last_date.loc[mask, 'Confirmed'] = np.nan
last_date.loc[mask, 'Deaths'] = np.nan
last_date.loc[mask, 'Recovered'] = np.nan

last_date = last_date[last_date['Confirmed'] >0]
last_date = last_date.groupby('Country')['Date'].agg(['max']).reset_index()

first_last = pd.concat([first_date, last_date['max']],axis = 1)
first_last['max'] = first_last['max'] + timedelta(days = 1)

first_last['Days'] = first_last['max'] - first_last['min']
first_last['Task'] = first_last['Country']

first_last.columns = ['Country','Start','Finish','Days','Task']

first_last = first_last.sort_values('Days')

colors = ['#' + ''.join([random.choice('0123456789ABCDEF') for j in range(6)]) for i in range(len(first_last))]

fig = ff.create_gantt(first_last, index_col = 'Country',colors = colors,show_colorbar = False,
                     bar_width = 0.2,showgrid_x = True,showgrid_y = True ,height = 2500)

fig.show()


# # Confirmed Cases Country and Daywise

# In[56]:


country_daywise.head()


# In[57]:


temp = country_daywise.groupby(['Country','Date'])['Confirmed'].sum().reset_index()
temp = temp[temp['Country'].isin(gt_10000)]

countries = temp['Country'].unique()

ncols = 3
nrows = math.ceil(len(countries)/ncols)

fig = make_subplots(rows = nrows,cols = ncols,shared_xaxes = False,subplot_titles = countries)

for ind, country in enumerate (countries) :
    row = int((ind/ncols)+1)
    col = int((ind%ncols)+1)
    fig.add_trace(go.Bar(x = temp['Date'],y = temp.loc[temp['Country'] == country,'Confirmed'],name = country),row = row,col = col)
fig.update_layout(height = 4000,title_text = 'Confirmed cases in each country')
fig.update_layout(showlegend = False)
fig.show()


# # Covid-19 Vs Other Similar Epidemics

# In[ ]:


epidemics = pd.DataFrame({
    'epidemic' : ['COVID-19','SARS','EBOLA','MERS','H1N1'],
    'start_year' : [2019,2002,2013,2012,2009],
    'end_year' : [2020,2004,2016,2020,2010],
    'confirmed' : [full_latest['Confirmed'].sum(),8422,28646,2519,6724149],
    'deaths' : [full_latest['Deaths'].sum(),813,11323,866,19654]
})

epidemics['mortality'] = round((epidemics['deaths']/epidemics['confirmed'])*100,2)

epidemics.head()


# In[ ]:


temp = epidemics.melt(id_vars = 'epidemic',value_vars = ['confirmed','deaths','mortality'],
                     var_name = 'Case',value_name = 'Value')
temp


# In[ ]:


fig = px.bar(temp,x = 'epidemic',y = 'Value',color = 'epidemic',text = 'Value',facet_col = 'Case',
            color_discrete_sequence = px.colors.qualitative.Bold)
fig.update_traces(textposition = 'outside')


# In[ ]:


df.columns


# In[62]:


country_daywise.columns


# In[63]:


countrywise.columns


# In[64]:


daywise.columns


# In[65]:


fig = px.scatter_3d(df, x='Confirmed', y='Deaths', z='Recovered', color='Active')
fig.show()


# In[66]:


fig = px.scatter_3d(country_daywise, x='New Cases', y='New Deaths', z='New Recovered', color='Active')
fig.show()


# In[67]:


fig = px.scatter_3d( countrywise,x='Deaths / 100 Cases', y='Recovered / 100 Cases', z='Deaths / 100 Recovered',
                    color='Population')
fig.show()


# In[68]:


fig = px.scatter_3d(daywise, x='Confirmed', y='Deaths', z='Recovered', color='Active')
fig.show()


# # Plot Using Seaborn

# In[69]:


sns.pairplot(df)

